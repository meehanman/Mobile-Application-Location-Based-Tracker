$(function () {
    $('#btn-login').click(function () {
        $(this).attr("value", "loading...");
    });
});